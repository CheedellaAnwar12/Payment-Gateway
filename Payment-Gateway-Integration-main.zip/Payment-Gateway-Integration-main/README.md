# Payment-Gateway-Integration
This Application allows user to make payment. On clicking the donate button, the user will land on the payment page where user can select the amount to be paid and the payment type, e.g credit card, upi, etc .Once the payment is done the invoice will be generated and email will be sent.
<br><br>
Demonstration:
https://github.com/psaikeshav/Payment-Gateway-Integration/assets/98534285/ba0a73c7-c7ec-4bb0-9028-111386be9373
